---
name: kostenzeile
description: Kostenzeile unter jeder Antwort in Claude Code – Kosten, Token, Dauer (Arbeit, Frage, heute, gesamt) als API-Gegenwert in US-Dollar aus dem Sitzungsprotokoll. Immer verwenden, bevor eine Antwort endet, und wenn die Kostenzeile fehlt, tools/kosten.py nicht existiert oder nach Kosten, Token oder Dauer des Chats gefragt wird.
---

# Kostenzeile

Jede Antwort endet mit genau einer Kostenzeile. Ablauf pro Antwort:

1. `python3 tools/kosten.py` im Projektverzeichnis ausführen.
2. Die Ausgabe **wörtlich** als letzte Zeile der Antwort setzen: roh, nicht in einen Codeblock,
   nicht umformatieren, nichts dahinter, nicht schätzen. Sie sieht so aus:

   <sub>26.09. 19:38 Uhr · Arbeit 2 min · Frage 2,81 · heute 7,54 · ges. 38,72 $</sub>

## Fehlt tools/kosten.py im Projekt

1. `kosten.py` aus diesem Skill-Ordner nach `tools/kosten.py` im Projekt kopieren.
2. Committen und auf den Arbeitsbranch pushen. Sonst fehlt die Datei in der nächsten Cloud-Sitzung,
   und der Stop-Hook meldet ungetrackte Dateien.
3. Dann wie oben ausführen.

## Läuft das Skript nicht

Kein Sitzungsprotokoll, Aufruf blockiert oder anderes Werkzeug: das offen in einem Satz sagen
statt eine Zahl zu erfinden. Eine ältere Zeile aus demselben Chat nur mit dem Hinweis zeigen, dass
sie nicht aktuell ist.

## Freigabe

Damit der Aufruf nicht blockiert oder nachgefragt wird, braucht es die Bash-Regeln
`Bash(python3 tools/kosten.py)` und `Bash(python3 tools/kosten.py *)` in `~/.claude/settings.json`,
in der Cloud über das Setup-Skript der Umgebung angelegt. Diese Datei nicht selbst anlegen oder
ändern, das entscheidet der Nutzer.

## Bedeutung der Zahlen

- **Arbeit** – Zeit seit dem letzten echten Nutzerbeitrag (ohne das Schreiben dieser Antwort).
- **Frage** – Kosten aller Antworten seit dem letzten echten Nutzerbeitrag.
- **heute** – lokaler Tag (Europe/Berlin), über alle Projekte. Entfällt, wenn nur diese Sitzung sichtbar ist (Cloud: ein Container je Sitzung) – dort wäre es immer gleich „ges.“.
- **ges.** – die gesamte laufende Sitzung.

API-Listenpreise, keine Rechnung; Untergrenze, da Nebenaufrufe der Plattform fehlen.
`python3 tools/kosten.py -v` zeigt Summen je Tag und Modell.
